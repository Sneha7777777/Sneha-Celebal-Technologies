#2  python-arithmetic-operators
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

print("Sum: ", a + b)
print("Difference: ", a - b)
print("Product: ", a * b)