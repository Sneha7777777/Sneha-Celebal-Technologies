#3 compress-the-string
from itertools import groupby

s = input("Enter: ")
for k, g in groupby(s):
    print(f"({len(list(g))}, {k})", end=' ')